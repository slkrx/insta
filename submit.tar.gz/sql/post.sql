SELECT user_post_comments_likes.*,
    L.owner AS 'liked_by_user'
FROM (
        SELECT COUNT(L.postid) AS 'likes',
            user_post_comments.*
        FROM (
                SELECT post_comments.*,
                    '/uploads/' || U.filename AS 'owner_img_url'
                FROM (
                        SELECT ARRAY(C.commentid, C.owner, C.text) AS 'comments',
                            P.postid,
                            P.owner,
                            '/uploads/' || P.filename AS 'img_url',
                            P.created AS 'timestamp'
                        FROM posts P
                            LEFT JOIN comments C ON P.postid = C.postid
                        WHERE P.postid = :postid
                        GROUP BY P.postid
                        ORDER BY C.created DESC,
                            C.commentid
                    ) post_comments
                    INNER JOIN users U ON U.username = post_comments.owner
            ) user_post_comments
            LEFT JOIN likes L ON L.postid = user_post_comments.postid
        GROUP BY L.postid
    ) user_post_comments_likes
    LEFT JOIN likes L ON user_post_comments_likes.postid = L.postid
    AND L.owner = :username;
SELECT UserPostsFollowingFollowers.*,
    Following.username1 AS 'followed_by_current_user'
FROM (
        SELECT COUNT(Followers.username1) as 'followers',
            UserPostsFollowing.*
        FROM (
                SELECT COUNT(Following.username2) as 'following',
                    UserPosts.*
                FROM (
                        SELECT ARRAY(Posts.postid, '/uploads/' || Posts.filename) AS 'posts',
                            COUNT(Posts.postid) AS 'total_posts',
                            User.*
                        FROM (
                                SELECT Users.username,
                                    Users.fullname
                                FROM users Users
                                WHERE Users.username = :username
                            ) User
                            LEFT JOIN posts Posts ON Posts.owner = User.username
                        ORDER BY Posts.created
                    ) UserPosts
                    LEFT JOIN following Following ON UserPosts.username = Following.username1
            ) UserPostsFollowing
            LEFT JOIN following Followers ON UserPostsFollowing.username = Followers.username2
    ) UserPostsFollowingFollowers
    LEFT JOIN following Following ON UserPostsFollowingFollowers.username = Following.username2
    AND Following.username1 = :logname;
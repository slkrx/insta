PRAGMA foreign_keys = ON;

CREATE TABLE users
(
	username VARCHAR(20) PRIMARY KEY,
	fullname VARCHAR(40) NOT NULL,
	email VARCHAR(40),
	filename VARCHAR(64),
	password VARCHAR(256),
	created DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE posts
(
	postid INTEGER PRIMARY KEY,
	filename VARCHAR(64),
	owner VARCHAR(20),
	created DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT		fk_posts_owner
		FOREIGN KEY	(owner)
		REFERENCES	users(username)
		ON DELETE	CASCADE
		ON UPDATE	CASCADE
);

CREATE TABLE following
(
	username1 VARCHAR(20),
	username2 VARCHAR(20),
	created DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY(username1, username2),
	CONSTRAINT 		[fk_following_username1]
		FOREIGN KEY (username1)
		REFERENCES 	users(username)
		ON DELETE 	CASCADE
		ON UPDATE 	CASCADE,
	CONSTRAINT 		[fk_following_username2]
		FOREIGN KEY (username2)
		REFERENCES 	users (username)
		ON DELETE 	CASCADE
		ON UPDATE 	CASCADE
);

CREATE TABLE comments
(
	commentid INTEGER PRIMARY KEY,
	owner VARCHAR(20),
	postid INTEGER,
	text VARCHAR(1024),
	created DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT 		[fk_comments_owner]
		FOREIGN KEY (owner)
		REFERENCES 	users(username)
		ON DELETE 	CASCADE
		ON UPDATE 	CASCADE,
	CONSTRAINT 		[fk_comments_postid]
		FOREIGN KEY (postid)
		REFERENCES 	posts (postid)
		ON DELETE 	CASCADE
		ON UPDATE 	CASCADE
);

CREATE TABLE likes
(
	owner VARCHAR(20),
	postid INTEGER,
	created DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
	PRIMARY KEY(owner, postid),
	CONSTRAINT		[fk_likes_owner]
		FOREIGN KEY	(owner)
		REFERENCES	users(username)
		ON DELETE 	CASCADE
		ON UPDATE 	CASCADE,
	CONSTRAINT		[fk_likes_postid]
		FOREIGN KEY (postid)
		REFERENCES	posts (postid)
		ON DELETE	CASCADE
		ON UPDATE	CASCADE
);
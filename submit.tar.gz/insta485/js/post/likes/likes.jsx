import React from 'react';
import PropTypes from 'prop-types';

class Likes extends React.Component {
  constructor(props) {
    super(props);
    this.handleClick = this.handleClick.bind(this);
  }

  handleClick() {
    const { onLikeButtonClick } = this.props;
    onLikeButtonClick();
  }

  render() {
    const { likesCount, lognameLikesThis } = this.props;
    return (
      <div>
        <button className="like-unlike-button" type="button" onClick={this.handleClick}>
          {lognameLikesThis === 1 ? 'unlike' : 'like'}
        </button>
        <div>
          {likesCount + (likesCount === 1 ? ' like' : ' likes') }
        </div>
      </div>
    );
  }
}

Likes.propTypes = {
  onLikeButtonClick: PropTypes.func.isRequired,
  likesCount: PropTypes.number.isRequired,
  lognameLikesThis: PropTypes.number.isRequired,
};

export default Likes;

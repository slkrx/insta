import React from 'react';
import ReactDOM from 'react-dom';
import Posts from './posts';

// This method is only called once
ReactDOM.render(
  <Posts />,
  document.getElementById('reactEntry'),
);

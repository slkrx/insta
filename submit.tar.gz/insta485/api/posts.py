"""REST API for posts."""
import flask
import insta485
from .utils import utils


@insta485.app.route('/api/v1/p/<int:postid>/likes/', methods=["POST"])
@utils.require_login
@insta485.utils.database_query
@utils.require_post_existance
def create_like(postid):
    """create_like."""
    like_exists = bool(flask.g.sqlite_db.execute(
        "SELECT EXISTS( "
        "   SELECT 1 FROM likes "
        "   WHERE postid=:postid AND owner=:username "
        ") AS like_exists",
        {
            'postid': postid,
            'username': flask.session['user']
        }
    ).fetchone()['like_exists'])
    if like_exists:
        return(
            flask.jsonify(
                logname=flask.session['user'],
                message="Confilct",
                postid=postid,
                status_code=409
            ), 409
        )

    flask.g.sqlite_db.execute(
        "INSERT INTO likes (owner, postid) "
        "VALUES (:owner, :postid)",
        {
            'owner': flask.session['user'],
            'postid': postid
        }
    )
    return(
        flask.jsonify(
            logname=flask.session['user'],
            postid=postid
        ), 201
    )


@insta485.app.route('/api/v1/p/<int:postid>/likes/', methods=["DELETE"])
@utils.require_login
@insta485.utils.database_query
@utils.require_post_existance
def delete_like(postid):
    """delete_like."""
    flask.g.sqlite_db.execute(
        "DELETE FROM likes "
        "WHERE postid=:postid "
        "AND owner=:username",
        {
            "postid": postid,
            "username": flask.session['user']
        }
    )
    return '', 204


@insta485.app.route('/api/v1/p/<int:postid>/likes/', methods=["GET"])
@utils.require_login
@insta485.utils.database_query
@utils.require_post_existance
def get_likes(postid):
    """get_likes."""
    likes = flask.g.sqlite_db.execute(
        "SELECT "
        "COALESCE(:username IN (SELECT L.owner), 0) AS logname_likes_this, "
        "P.postid, "
        "'/api/v1/p/' || P.postid || '/likes/' AS url, "
        "COUNT(L.postid) likes_count "
        "FROM posts P "
        "LEFT JOIN likes L USING(postid) "
        "WHERE postid=:postid",
        {
            'postid': postid,
            'username': flask.session['user']
        }
    ).fetchone()

    return flask.jsonify(likes)


@insta485.app.route('/api/v1/p/<int:postid>/comments/', methods=["POST"])
@utils.require_login
@insta485.utils.database_query
@utils.require_post_existance
def create_comment(postid):
    """create_comment."""
    commentid = flask.g.sqlite_db.execute(
        "INSERT INTO comments "
        "(owner, postid, text) "
        "VALUES (:owner, :postid, :text)",
        {
            'owner': flask.session['user'],
            'postid': postid,
            'text': flask.request.json['text']
        }
    ).lastrowid

    return flask.make_response(flask.jsonify(
        commentid=commentid,
        owner=flask.session['user'],
        owner_show_url="/u/{}/".format(flask.session['user']),
        postid=postid,
        text=flask.request.json['text']
    ), 201)


@insta485.app.route('/api/v1/p/<int:postid>/comments/', methods=["GET"])
@utils.require_login
@insta485.utils.database_query
@utils.require_post_existance
def get_comments(postid):
    """get_comments."""
    comments = flask.g.sqlite_db.execute(
        "SELECT C.commentid, "
        "C.owner, "
        "'/u/' || C.owner || '/' AS owner_show_url, "
        "P.postid, "
        "C.text "
        "FROM "
        "comments C "
        "JOIN posts P USING(postid) "
        "WHERE P.postid = :postid ",
        {'postid': postid}
    ).fetchall()

    return flask.jsonify(comments=comments, url="/api/v1/p/3/comments/")


@insta485.app.route('/api/v1/p/', methods=["GET"])
@utils.require_login
@insta485.utils.database_query
def get_posts():
    """get_posts."""
    size = flask.request.args.get("size", default=10, type=int)
    page = flask.request.args.get("page", default=0, type=int)

    query = ("SELECT postid "
             "FROM posts "
             "WHERE owner IN ( "
             "SELECT username2 "
             "FROM following "
             "WHERE username1 = :username "
             ") "
             "OR owner = :username "
             "ORDER BY postid DESC "
             "LIMIT :row_count OFFSET :offset ")
    query_parameters = {
        'username': flask.session['user'],
        'row_count': size,
        'offset': page * size
    }

    postids = flask.g.sqlite_db.execute(query, query_parameters)  # .fetchall()

    query_parameters['offset'] += size
    if (bool(
        flask.g.sqlite_db.execute(query, query_parameters).fetchall()
    )):
        next_page_url = flask.url_for('get_posts', size=size, page=page + 1)
    else:
        next_page_url = ''
    posts = list(
        map(
            lambda postid: {"url": flask.url_for(
                'get_post', postid=postid['postid']), **postid},
            postids
        )
    )
    return flask.jsonify(next=next_page_url, results=posts, url="/api/v1/p/")


@insta485.app.route('/api/v1/p/<int:postid>/', methods=["GET"])
@insta485.utils.database_query
@utils.require_login
@utils.require_post_existance
def get_post(postid):
    """Return post on postid."""
    post = flask.g.sqlite_db.execute(
        "SELECT P.created AS age, "
        "'/uploads/' || P.filename AS img_url, "
        "P.owner, "
        "'/uploads/' || U.filename AS owner_img_url, "
        "'/u/' || U.username || '/' AS owner_show_url, "
        "'/p/' || P.postid || '/' AS post_show_url, "
        "'/api/v1/p/3/' || P.postid || '/' AS url "
        "FROM posts P "
        "JOIN users U ON P.owner = U.username "
        "WHERE P.postid = :postid ",
        {'postid': postid}
    ).fetchone()

    return flask.jsonify(post)

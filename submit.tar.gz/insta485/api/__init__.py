"""Insta485 REST API."""

from insta485.api.posts import get_posts
from insta485.api.posts import get_post
from insta485.api.posts import get_likes
from insta485.api.posts import create_like
from insta485.api.posts import delete_like
from insta485.api.posts import create_comment
from insta485.api.posts import get_comments
from insta485.api.index import get_index

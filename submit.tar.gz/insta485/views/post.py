"""
Insta485 post (detail) view.

URLs include:
/p/<postid_url_slug>
"""
import ast
import arrow
import flask
import insta485
from .utils import utils


def step(self, commentid, owner, text):
    """."""
    if commentid and owner and text:
        self.collection.append(
            {'commentid': commentid, 'owner': owner, 'text': text})


@insta485.app.route('/p/<postid_url_slug>/')
@insta485.utils.database_query
@utils.uses_array_aggregator(step, 3)
@utils.must_be_logged_in('redirect')
def show_post(postid_url_slug):
    """."""
    post = flask.g.sqlite_db.execute(utils.query_from_sql_file('post.sql'), {
        'postid': postid_url_slug,
        'username': flask.session['user']}).fetchone()
    post['comments'] = ast.literal_eval(post['comments'])
    post['timestamp'] = arrow.get(post['timestamp']).humanize()

    return flask.render_template("show_post.html", post=post)

"""
Insta485 index (main) view.

URLs include:
/
"""
from ast import literal_eval
import arrow
import flask
import insta485
from .utils import utils


def step(self, owner, text, commentid):
    """."""
    if owner and text and commentid:
        self.collection.append(
            {'owner': owner, 'text': text, 'commentid': commentid})


@insta485.utils.database_query
@utils.uses_array_aggregator(step, 3)
def get_posts():
    """."""
    return(flask.g.sqlite_db.execute(
        utils.query_from_sql_file('posts.sql'),
        {'username': flask.session['user']}
    ).fetchall())


@insta485.app.route('/')
@utils.must_be_logged_in('redirect')
def show_index():
    """Display / route."""
    posts = get_posts()
    for post in posts:
        post['comments'] = literal_eval(post['comments'])
        post['comments'].sort(key=lambda comment: comment['commentid'])
        post['timestamp'] = arrow.get(post['timestamp']).humanize()

    return flask.render_template("index.html", posts=posts)

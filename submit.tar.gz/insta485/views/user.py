"""
Insta485 user view.

URLs include:
/u/<user_url_slug>/
"""
from ast import literal_eval
import flask
import insta485
from .utils import utils


@insta485.utils.database_query
@utils.uses_array_aggregator(utils.postid_img_url_step, 2)
def get_user(user_url_slug):
    """."""
    return(flask.g.sqlite_db.execute(
        utils.query_from_sql_file('user.sql'), {
            "username": user_url_slug,
            'logname': flask.session['user']
        }).fetchone())


@insta485.app.route('/u/<user_url_slug>/')
@utils.must_be_logged_in('redirect')
@utils.user_must_exist
def show_user(user_url_slug):
    """."""
    user = get_user(user_url_slug)
    user['relationship'] = utils.user_user_relationship(
        flask.session['user'], user)
    # Split posts string into an array
    user['posts'] = literal_eval(user['posts'])

    context = user
    return flask.render_template("show_user.html", **context)
